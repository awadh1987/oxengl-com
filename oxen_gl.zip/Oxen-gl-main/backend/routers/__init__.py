"""Routers bridge module."""
