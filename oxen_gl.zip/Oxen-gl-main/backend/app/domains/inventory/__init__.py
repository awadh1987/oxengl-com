"""OxenGL Inventory Domain Module."""
